from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import cv2
import imutils
import numpy as np
import os

from uploads.core.models import Document
from uploads.core.forms import DocumentForm

def ConvertIntoMaskedVideo(InputFilePath):
    #fgbg=cv2.bgsegm.createBackgroundSubtractorMOG()
    fgbg= cv2.createBackgroundSubtractorMOG2(detectShadows = False)
    #fgbg= cv2.createBackgroundSubtractorKNN()

    
    OutputFilePath=''



    if len(OutputFilePath)==0:
        OutputFilePath=InputFilePath.replace('.mp4','_processed.mp4')

    cap = cv2.VideoCapture(InputFilePath)

    TargetFPS=int(cap.get(cv2.CAP_PROP_FPS))
    TargetHeight=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    TargetWidth=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))


    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(OutputFilePath, fourcc, TargetFPS, (TargetWidth,TargetHeight))

    while(cap.isOpened()):
        ret,frame = cap.read()
        if ret:

            fgmask = fgbg.apply(frame,0.005)

            for RowInd , PixelRow in enumerate(fgmask):
                for ColInd , PixelCol in enumerate(PixelRow):
                    if PixelCol < 250:
                        frame[RowInd, ColInd, 0] = 0
                        frame[RowInd, ColInd, 1] = 0
                        frame[RowInd, ColInd, 2] = 0



            out.write(frame)          #Save it
            #cv2.imshow('Background Subtraction', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break                 #q to quit
        else:
            break                     #EOF

    cap.release()
    out.release()
    cv2.destroyAllWindows()





def home(request):
    documents = Document.objects.all()
    return render(request, 'core/home.html', { 'documents': documents })


def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        print(myfile.name)
        print(settings.MEDIA_ROOT)

        ConvertIntoMaskedVideo(settings.MEDIA_ROOT+"\\"+ myfile.name)
        uploaded_file_url = fs.url(myfile.name.replace('.mp4','_processed.mp4'))

        return render(request, 'core/simple_upload.html', {
            'uploaded_file_url': uploaded_file_url})

    return render(request, 'core/simple_upload.html')


def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = DocumentForm()
    return render(request, 'core/model_form_upload.html', {
        'form': form
    })
